<?php
// Directory where uploaded files will be saved
$uploadDir = 'uploads/';

// Ensure the directory exists
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Check if a file was uploaded
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo "Error: " . $file['error'];
        exit;
    }

    // Generate a unique filename to avoid overwriting
    $fileName = basename($file['name']);
    $targetFilePath = $uploadDir . uniqid() . '-' . $fileName;

    // Move the uploaded file to the target directory
    if (move_uploaded_file($file['tmp_name'], $targetFilePath)) {
        echo "File uploaded successfully: " . $targetFilePath;
    } else {
        echo "Failed to upload file.";
    }
} else {
    echo "No file uploaded.";
}
?>